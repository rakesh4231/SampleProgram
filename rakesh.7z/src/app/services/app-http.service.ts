import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class AppHttpService {
  apiUrl = 'https://jsonplaceholder.typicode.com/posts';

  constructor(private https: HttpClient) {
  }

  /**
   * http get request
   * @param URL api url to make the request
   * @returns Observable
   */
  getService(): Observable<any> {
    return this.https.get(this.apiUrl);
  }

}
