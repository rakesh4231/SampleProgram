import { Component, OnInit } from '@angular/core';
import { AppHttpService } from 'src/app/services/app-http.service';


@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.scss']
})
export class PostsComponent implements OnInit {

  postsList = [{userId:"1",title:"Sample"}];

  constructor(private appService: AppHttpService) { }

  ngOnInit() {
    this.getPostsData();
  }

  getPostsData() {
    this.appService.getService().subscribe({
      next: (resp: any) => {
        this.postsList = resp;
      },
      error: err => {
        console.log(err);
      },
      complete: () => {
      }
    });
  }


}
