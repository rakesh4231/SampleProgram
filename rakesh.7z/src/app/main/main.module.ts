import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MainRoutingModule } from './main-routing.module';
import { MainComponent } from './main.component';
import { PostsComponent } from './posts/posts.component';
import { SharingComponent } from './sharing/sharing.component';
import { ContainerComponent } from './container/container.component';
import { SharingFormComponent } from './sharing/sharing-form/sharing-form.component';
import { SharingDataComponent } from './sharing/sharing-data/sharing-data.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppHttpService } from '../services/app-http.service';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  declarations: [MainComponent, PostsComponent, SharingComponent, ContainerComponent, SharingFormComponent, SharingDataComponent],
  imports: [
    CommonModule,
    MainRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxPaginationModule
  ],
  providers: [AppHttpService]
})
export class MainModule { }
