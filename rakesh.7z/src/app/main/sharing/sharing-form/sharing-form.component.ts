import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-sharing-form',
  templateUrl: './sharing-form.component.html',
  styleUrls: ['./sharing-form.component.scss']
})
export class SharingFormComponent implements OnInit {

  infoForm: FormGroup;
  @Output() messageToEmit = new EventEmitter<string>();

  constructor(private formBuilder: FormBuilder) {
    this.infoForm = this.formBuilder.group({
      infotext: [''],
    });
  }

  ngOnInit() {
  }

  onSubmit() {
    this.messageToEmit.emit(this.infoForm.value.infotext);
  }

}
