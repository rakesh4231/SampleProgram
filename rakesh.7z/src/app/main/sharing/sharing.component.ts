import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sharing',
  templateUrl: './sharing.component.html',
  styleUrls: ['./sharing.component.scss']
})
export class SharingComponent implements OnInit {

  displayText: string;

  constructor() { }

  ngOnInit() {
  }

  getMessage(message: string) {
    this.displayText = message;
  }

}
